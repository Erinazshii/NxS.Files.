# NEXUS ARG — Recovery Terminal

A single-file HTML/CSS/JS ARG prototype.

## Run locally
Open `index.html` in a browser.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and this README.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select `main` and `/root`.
6. Save.

## Current puzzle answers
1. SILENT
2. VECTOR
3. ERINASHII
4. ZERO
5. RETURN
6. 317
7. EMBER
8. YOUR DISCORD CHANNEL CODE — intentionally left customizable
9. NEXT
10. ALTERED
11. HIDE
12. Subject: EMPEROR ERINASHII / Date: 6/10/26 / Final Code: PROSECUTORS

## Important
The current binary/Caesar/Morse stage is a prototype presentation rather than a production-grade cryptographic chain. Replace its visible clues with your exact intended chain before launch.

The fake-code block is deliberately generated client-side so it looks large and noisy.

For a real ARG, consider splitting the recovered files into separate `.txt`/`.pdf` assets and using actual image evidence for Puzzle 6.
